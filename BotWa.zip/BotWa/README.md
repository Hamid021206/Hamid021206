<p align="center">
  <img alig src="https://i.pinimg.com/originals/e5/ce/bf/e5cebf7269f86a7b1d1799f0cb1bfa46.gif" />
</p>

<div align="center">
<img alt="GitHub" src="https://img.shields.io/badge/WHATSAPP%20BOT-25D32?style=for-the-badge&logoColor=darkgreen"/>
<br><br>
  
> A whatsapp bot made using adiwajshing/Baileys library


</div>

### Changelog
```rb
Added +4 Feature
- tiktok no wm download
- tiktok with wm download
- tiktok audio download
- soundcloud download

Deletion Feature/Function
- Nothing
```

### Install ⬇️

```bash
> apt-get update
> apt-get upgrade
> apt-get install nodejs git -y
> git clone https://github.com/hamid021206/hamid021206
> cd Exneph-bot
> bash install.sh
> npm install
> node .
```

## Note
if `bash install.sh` not work you can use `npm install` or use all no problem.
<br>
<br>
after start it you need to scan the qr (use 2 phone or 1 phone and 1 computer)

### Editing File
> You can edit edit configuration in file [`config.json`](https://github.com/Azyansah/Exneph-bot/blob/main/config.json).

### Contact me

- [`WHATSAPP`](http://wa.me/6282371973833)
- [`INSTAGRAM`](https://instagram.com/ha16507930@gmail.com)


## 🙏 Special Thanks to
* <a href="https://github.com/adiwajshing/Baileys"><img alt="GitHub" src="https://img.shields.io/badge/@adiwajshing/Baileys%20-%23121011.svg?style=flat-square&logo=github&color=green"/></a>
* <a href="https://github.com/mccnlight/Simple-selfbot"><img alt="GitHub" src="https://img.shields.io/badge/Lindow Amamiya%20-%23121011.svg?style=flat-square&logo=github&color=blue"/></a>
* <a href="https://github.com/Zobin33/Anu-wabot"><img alt="Github" src="https://img.shields.io/badge/Zobin (Galang)%20-%23121011.svg?style=flat-square&logo=github&color=blue"/></a>
* <a href="https://github.com/manxtodd"><img alt="Github" src="https://img.shields.io/badge/Manxtodd%20-%23121011.svg?style=flat-square&logo=github&color=blue"/></a>
* <a href="https://github.com/zenngans"><img alt="Github" src="https://img.shields.io/badge/ZennDie (Zainal Matih)%20-%23121011.svg?style=flat-square&logo=github&color=blue"/></a>
